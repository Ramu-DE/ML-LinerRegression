# Implementation Plan: Linear Regression Explainer

## Overview

Build a React (TypeScript) single-page application that teaches OLS regression through 16 sequential sections, each pairing an Explainer (narrative/derivations) with a Visualizer (Plotly charts, interactive controls). Implementation proceeds bottom-up: pure computation utilities first, then shared UI primitives, then section-by-section content, and finally navigation/wiring.

## Tasks

- [-] 1. Initialize project and core infrastructure
  - Scaffold a Vite + React + TypeScript project
  - Install dependencies: plotly.js, react-plotly.js, katex, react-katex, tailwindcss, fast-check, vitest, @testing-library/react
  - Configure Tailwind CSS and Vitest
  - _Requirements: 17_

- [ ] 2. Implement OLS computation utilities
  - [ ] 2.1 Implement `fitSimpleOLS`, `computeResiduals`, `computeSSR`, `computeRSquared`, `findMissingValueRows` as pure functions in `src/lib/ols.ts`
    - Include JSDoc and TypeScript types for all function signatures
    - _Requirements: 4.3, 6.1, 8.1, 9.1, 16.5_
  - [ ]* 2.2 Write unit tests for OLS utilities
    - Verify `fitSimpleOLS` on a known 3-point dataset
    - Verify `computeResiduals` matches manual calculation
    - Verify `computeSSR` = 0 when all points lie on the line
    - Verify `findMissingValueRows` returns correct indices
    - _Requirements: 4.3, 6.1_
  - [ ]* 2.3 Write property test for residual array length (Property 2)
    - **Property 2: Residual Line Count Equals Data Point Count**
    - **Validates: Requirements 3.4, 4.4**
  - [ ]* 2.4 Write property test for SSR display accuracy (Property 4)
    - **Property 4: SSR Display Equals Computed SSR for Any Line Position**
    - **Validates: Requirements 4.5, 6.2, 6.4**
  - [ ]* 2.5 Write property test for squared residual area (Property 5)
    - **Property 5: Squared Residual Area Equals Squared Residual Value**
    - **Validates: Requirements 5.3, 6.3**
  - [ ]* 2.6 Write property test for OLS reference line (Property 6)
    - **Property 6: OLS Reference Line Matches OLS Solution**
    - **Validates: Requirements 6.5**
  - [ ]* 2.7 Write property test for R² value accuracy (Property 10)
    - **Property 10: Displayed R² Equals ssReg / ssTot**
    - **Validates: Requirements 10.3**

- [ ] 3. Implement CSV parser and custom data input
  - [ ] 3.1 Implement CSV parser in `src/lib/csvParser.ts` that produces a `Dataset` or a `CustomDataInput` with `parseError` and `missingValueRows`
    - Handle missing cells, non-numeric columns, and empty files
    - _Requirements: 16.4, 16.5_
  - [ ]* 3.2 Write unit tests for CSV parser
    - Verify well-formed CSV produces expected `Dataset`
    - Verify CSV with missing cell produces correct `missingValueRows`
    - _Requirements: 16.4, 16.5_
  - [ ]* 3.3 Write property test for CSV round-trip (Property 17)
    - **Property 17: CSV Round-Trip Produces a Regression Result**
    - **Validates: Requirements 16.4**
  - [ ]* 3.4 Write property test for missing value notification (Property 18)
    - **Property 18: Missing Value Notification Lists Affected Row Indices**
    - **Validates: Requirements 16.5**

- [ ] 4. Implement navigation state and shell components
  - [ ] 4.1 Implement `NavigationState`, `NavigationAction`, and `useNavigationReducer` hook in `src/state/navigation.ts`
    - Handle `GO_TO`, `NEXT`, `BACK`, `TOGGLE_GLOSSARY` actions with bounds clamping
    - _Requirements: 17.1, 17.2, 17.3, 17.4_
  - [ ] 4.2 Implement `NavigationBar` component with progress indicator and Glossary button
    - _Requirements: 17.3, 17.4_
  - [ ] 4.3 Implement `SectionShell` two-column layout component
    - _Requirements: 17.1, 17.2_
  - [ ] 4.4 Implement `GlossaryDrawer` slide-in panel with all glossary terms
    - _Requirements: 17.4_
  - [ ]* 4.5 Write unit tests for navigation reducer
    - Verify clicking a visited section calls `onNavigate` with correct index
    - Verify opening/closing glossary does not change `currentIndex`
    - _Requirements: 17.2, 17.4_
  - [ ]* 4.6 Write property test for progress indicator (Property 19)
    - **Property 19: Progress Indicator Reflects Current Navigation Index**
    - **Validates: Requirements 17.3**
  - [ ]* 4.7 Write property test for glossary preserving section (Property 20)
    - **Property 20: Opening Glossary Does Not Change Current Section**
    - **Validates: Requirements 17.4**

- [ ] 5. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 6. Implement shared rendering primitives
  - [ ] 6.1 Implement `KaTeXRenderer` component wrapping react-katex for inline and block equations
    - _Requirements: 1.3, 8.1, 9.2, 13.3_
  - [ ] 6.2 Implement `DerivationStepper` component that renders a numbered list of steps, each with a label and plain-language interpretation
    - _Requirements: 8.4, 9.2, 9.3_
  - [ ] 6.3 Implement `AnnotatedFormulaDiagram` component rendering the labeled OLS equation (Yi = β0 + β1·Xi + εi) with colored brackets distinguishing linear and error components
    - _Requirements: 2.1, 2.2, 2.3, 2.4_
  - [ ]* 6.4 Write property test for annotated diagram completeness (Property 1)
    - **Property 1: Annotated Diagram Completeness**
    - **Validates: Requirements 2.2, 2.4**

- [ ] 7. Implement sections 1–3 (OLS Intro, Annotated Formula, Regression Line)
  - [ ] 7.1 Implement `OlsIntroSection` with plain-language definition, real-world examples, and the general linear equation rendered via `KaTeXRenderer`
    - _Requirements: 1.1, 1.2, 1.3_
  - [ ] 7.2 Implement `AnnotatedFormulaSection` using `AnnotatedFormulaDiagram` and `ExplainerPanel` prose
    - _Requirements: 2.1, 2.2, 2.3, 2.4_
  - [ ] 7.3 Implement `RegressionLineSection` with a Plotly scatter plot, overlaid best-fit line, intercept annotation, slope rise/run triangle, and vertical residual lines
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  - [ ]* 7.4 Write property test for intercept annotation (Property 3)
    - **Property 3: Intercept Annotation Matches OLS Intercept**
    - **Validates: Requirements 3.2**

- [ ] 8. Implement `InteractiveLineFitter` and sections 4–6 (Residuals, Squared Residuals, Interactive Fitting)
  - [ ] 8.1 Implement `InteractiveLineFitter` component with slope/intercept sliders, `ResidualOverlay`, `SquaredResidualOverlay`, and `SSRDisplay`; wire OLS reference line
    - _Requirements: 4.4, 4.5, 5.1, 5.2, 5.3, 5.4, 5.5, 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_
  - [ ] 8.2 Implement `ResidualsAndSosSection` using `InteractiveLineFitter` with `showSquaredResiduals=false`
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_
  - [ ] 8.3 Implement `SquaredResidualsSection` using `InteractiveLineFitter` with `showSquaredResiduals=true` and side-by-side layout
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_
  - [ ] 8.4 Implement `InteractiveFittingSection` wiring all interactive controls and the OLS reference line display
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 6.6_

- [ ] 9. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 10. Implement sections 7–8 (Coefficients, Matrix Derivation)
  - [ ] 10.1 Implement `CoefficientsSection` with definitions, worked numeric example, and "holding other variables constant" explanation
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_
  - [ ] 10.2 Implement `MatrixDerivationSection` using `DerivationStepper` for the four-step derivation and `KaTeXRenderer` for the OLS solution formula and simple-case formula
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_
  - [ ]* 10.3 Write property test for matrix derivation step count (Property 7)
    - **Property 7: Matrix Derivation Has Exactly Four Steps**
    - **Validates: Requirements 8.4**

- [ ] 11. Implement sections 9–10 (R² Derivation, Variance Decomposition)
  - [ ] 11.1 Implement `RSquaredDerivationSection` using `DerivationStepper` for the four-step R² derivation with labels and interpretations
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_
  - [ ] 11.2 Implement `VarianceDecompositionChart` stacked bar chart with consistent SS_tot/SS_res/SS_reg color coding and R² display
    - _Requirements: 10.1, 10.2, 10.3, 10.4_
  - [ ] 11.3 Implement `VarianceDecompositionSection` with low-R² vs high-R² side-by-side comparison
    - _Requirements: 10.5_
  - [ ]* 11.4 Write property test for R² derivation completeness (Property 8)
    - **Property 8: R² Derivation Completeness**
    - **Validates: Requirements 9.2, 9.3**
  - [ ]* 11.5 Write property test for decomposition color consistency (Property 9)
    - **Property 9: Variance Decomposition Colors Are Distinct and Consistent**
    - **Validates: Requirements 10.2**

- [ ] 12. Implement `RegressionOutputTable` and sections 11–13 (T-Stats, Output Table, CIs)
  - [ ] 12.1 Implement `RegressionOutputTable` component with six columns, hoverable column-header tooltips, and non-significant row flagging
    - _Requirements: 11.6, 12.1, 12.2, 12.3, 12.5_
  - [ ] 12.2 Implement `TStatsPValuesSection` with definitions, worked example, and null hypothesis explanation
    - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5, 11.6_
  - [ ] 12.3 Implement `OutputTableSection` with the regression output table and walked narrative
    - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5_
  - [ ] 12.4 Implement `ConfidenceIntervalsSection` with CI formula, coefficient plot with error bars, and CI/p-value relationship explanation
    - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_
  - [ ]* 12.5 Write unit test for `RegressionOutputTable` snapshot
    - Verify all 6 columns render for a known result
    - _Requirements: 12.1, 12.2_
  - [ ]* 12.6 Write property test for non-significant variable flagging (Property 11)
    - **Property 11: Non-Significant Variables Are Flagged**
    - **Validates: Requirements 11.6**
  - [ ]* 12.7 Write property test for column annotations (Property 12)
    - **Property 12: Each Column Header Has an Annotation**
    - **Validates: Requirements 12.2**
  - [ ]* 12.8 Write property test for table row count (Property 13)
    - **Property 13: Table Row Count Equals Number of Predictors Plus One**
    - **Validates: Requirements 12.3**
  - [ ]* 12.9 Write property test for CI error bar bounds (Property 14)
    - **Property 14: Coefficient Plot Error Bars Span the 95% CI**
    - **Validates: Requirements 13.4**

- [ ] 13. Checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 14. Implement sections 14–15 (Multiple Regression, Diagnostic Plots)
  - [ ] 14.1 Implement `MultipleRegressionSection` with side-by-side simple/multiple formulas, two-predictor worked example, and 3D scatter plot with regression plane via Plotly
    - _Requirements: 14.1, 14.2, 14.3, 14.4, 14.5_
  - [ ] 14.2 Implement `DiagnosticPlots` component rendering Residuals vs Fitted, Q-Q, and Scale-Location plots; each accepts a `violationMode` prop
    - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5, 15.6_
  - [ ] 14.3 Implement `DiagnosticPlotsSection` showing side-by-side assumption-met and assumption-violated variants for all three plot types
    - _Requirements: 15.7_
  - [ ]* 14.4 Write property test for diagnostic plot variants (Property 15)
    - **Property 15: Each Diagnostic Plot Renders Both Variants**
    - **Validates: Requirements 15.7**

- [ ] 15. Implement section 16 (Worked Example)
  - [ ] 15.1 Implement `WorkedExample` component with built-in sample dataset, full summary output display, step-by-step narrative, and CSV upload with missing-value handling
    - _Requirements: 16.1, 16.2, 16.3, 16.4, 16.5_
  - [ ] 15.2 Implement `WorkedExampleSection` wiring `WorkedExample` into the section shell
    - _Requirements: 16.1, 16.2, 16.3, 16.4, 16.5_
  - [ ]* 15.3 Write property test for worked example summary completeness (Property 16)
    - **Property 16: Worked Example Summary Contains All Required Elements**
    - **Validates: Requirements 16.2**

- [ ] 16. Wire all sections into `SectionRouter` and `App`
  - [ ] 16.1 Implement `SectionRouter` mapping each of the 16 section keys to its component, driven by `NavigationState`
    - _Requirements: 17.1_
  - [ ] 16.2 Implement root `App` component composing `NavigationBar`, `SectionRouter`, and `GlossaryDrawer`; wire `useNavigationReducer` through React Context
    - _Requirements: 17.1, 17.2, 17.3, 17.4_

- [ ] 17. Final checkpoint — Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for a faster MVP
- Each task references specific requirements for traceability
- Property tests use fast-check with a minimum of 100 iterations per test
- Each property test file must include the comment `// Feature: linear-regression-explainer, Property N: <property text>`
- Checkpoints ensure incremental validation after each major phase
