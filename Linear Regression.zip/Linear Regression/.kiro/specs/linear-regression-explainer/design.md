# Design Document: Linear Regression Explainer

## Overview

The Linear Regression Explainer is an interactive, browser-based educational module that teaches beginners the fundamentals of Ordinary Least Squares (OLS) regression. It progresses from plain-language intuition through geometric visualization, algebraic derivation, and statistical inference, culminating in a fully interactive worked example and diagnostic plots.

The module is structured as a single-page application (SPA) with 16 sequential sections. Each section pairs an Explainer component (narrative text, step-by-step derivations, worked examples) with a Visualizer component (static annotated diagrams, interactive plots, 3D scatter plots). A persistent sidebar provides glossary access and a progress indicator.

### Technology Stack

- **Frontend framework**: React (TypeScript) — component-based architecture maps cleanly to the Explainer/Visualizer split
- **Plotting library**: Plotly.js — handles 2D scatter plots, residual overlays, and 3D scatter/plane rendering without a separate 3D library
- **Math rendering**: KaTeX — lightweight LaTeX rendering for inline and block equations
- **Styling**: Tailwind CSS — utility-first, keeps component styles co-located
- **State management**: React Context + `useReducer` — sufficient for section navigation and interactive line state; no need for a heavier store
- **Property-based testing**: fast-check (TypeScript) — mature PBT library with good React/DOM integration
- **Unit testing**: Vitest + React Testing Library

### Design Rationale

The Explainer/Visualizer split from the requirements maps directly to a component boundary: `<ExplainerPanel>` renders prose and derivations; `<VisualizerPanel>` renders Plotly figures. This separation keeps narrative logic independent of rendering logic, making both easier to test and iterate on.

Interactive state (slider positions, custom data) is kept local to each section component and lifted only when two sibling components need to share it (e.g., the linked residual/squared-residual plots in Requirements 5–6).

---

## Architecture

```mermaid
graph TD
    App --> NavigationBar
    App --> SectionRouter
    App --> GlossaryDrawer

    SectionRouter --> SectionShell
    SectionShell --> ExplainerPanel
    SectionShell --> VisualizerPanel

    ExplainerPanel --> KaTeXRenderer
    ExplainerPanel --> DerivationStepper
    ExplainerPanel --> WorkedExample

    VisualizerPanel --> AnnotatedFormulaDiagram
    VisualizerPanel --> ScatterPlot
    VisualizerPanel --> InteractiveLineFitter
    VisualizerPanel --> VarianceDecompositionChart
    VisualizerPanel --> RegressionOutputTable
    VisualizerPanel --> DiagnosticPlots
    VisualizerPanel --> ThreeDScatterPlot

    InteractiveLineFitter --> ResidualOverlay
    InteractiveLineFitter --> SquaredResidualOverlay
    InteractiveLineFitter --> SSRDisplay
```

### Section Sequence (Requirement 17.1)

| # | Section Key | Requirements |
|---|-------------|--------------|
| 1 | `ols-intro` | 1 |
| 2 | `annotated-formula` | 2 |
| 3 | `regression-line` | 3 |
| 4 | `residuals-sos` | 4 |
| 5 | `squared-residuals` | 5 |
| 6 | `interactive-fitting` | 6 |
| 7 | `coefficients` | 7 |
| 8 | `matrix-derivation` | 8 |
| 9 | `r-squared-derivation` | 9 |
| 10 | `variance-decomposition` | 10 |
| 11 | `t-stats-pvalues` | 11 |
| 12 | `output-table` | 12 |
| 13 | `confidence-intervals` | 13 |
| 14 | `multiple-regression` | 14 |
| 15 | `diagnostic-plots` | 15 |
| 16 | `worked-example` | 16 |

---

## Components and Interfaces

### `SectionShell`

Wraps every section. Provides the two-column layout (Explainer left, Visualizer right) and injects the current section's navigation callbacks.

```typescript
interface SectionShellProps {
  sectionKey: string;
  onNext: () => void;
  onBack: () => void;
  children: React.ReactNode;
}
```

### `NavigationBar`

Renders the progress indicator (Requirement 17.3) and a "Glossary" button that opens `GlossaryDrawer` without leaving the current section (Requirement 17.4).

```typescript
interface NavigationBarProps {
  sections: SectionMeta[];
  currentIndex: number;
  visitedIndices: Set<number>;
  onNavigate: (index: number) => void;
  onOpenGlossary: () => void;
}
```

### `InteractiveLineFitter`

The core interactive component used in Requirements 4–6. Manages slope/intercept state and broadcasts updates to linked child components.

```typescript
interface LineFitterState {
  slope: number;
  intercept: number;
  olsSlope: number;       // read-only reference line
  olsIntercept: number;
}

interface InteractiveLineFitterProps {
  data: DataPoint[];
  showSquaredResiduals: boolean;
  showOlsReference: boolean;
}
```

### `RegressionOutputTable`

Renders the statsmodels-style table (Requirement 12). Each column header is hoverable to reveal its annotation tooltip.

```typescript
interface RegressionRow {
  label: string;          // "const", "x1", etc.
  coef: number;
  stdErr: number;
  tStat: number;
  pValue: number;
  ci95Low: number;
  ci95High: number;
}

interface RegressionOutputTableProps {
  rows: RegressionRow[];
}
```

### `DiagnosticPlots`

Renders the three diagnostic plots side by side (Requirement 15). Each plot accepts a `violationMode` prop to show the "assumption violated" variant alongside the "assumption met" variant.

```typescript
type DiagnosticPlotType = 'residuals-vs-fitted' | 'qq' | 'scale-location';

interface DiagnosticPlotProps {
  residuals: number[];
  fittedValues: number[];
  plotType: DiagnosticPlotType;
  violationMode?: boolean;
}
```

### `VarianceDecompositionChart`

Stacked bar chart showing SS_tot = SS_reg + SS_res with consistent color coding (Requirement 10).

```typescript
interface VarianceDecompositionProps {
  ssTot: number;
  ssRes: number;
  ssReg: number;
  rSquared: number;
}
```

### `WorkedExample`

Manages the full end-to-end example (Requirement 16). Accepts either the built-in sample dataset or a user-uploaded CSV.

```typescript
interface WorkedExampleProps {
  defaultDataset: Dataset;
}

interface Dataset {
  name: string;
  x: number[][];   // columns of independent variables
  y: number[];
  columnNames: string[];
}
```

### `GlossaryDrawer`

Slide-in panel rendering all glossary terms from the requirements. Accessible from any section without navigation.

```typescript
interface GlossaryEntry {
  term: string;
  definition: string;
}
```

---

## Data Models

### Core Regression Types

```typescript
// A single observation
interface DataPoint {
  x: number;
  y: number;
}

// Result of fitting OLS on a simple (single-predictor) dataset
interface SimpleOLSResult {
  slope: number;
  intercept: number;
  residuals: number[];
  fittedValues: number[];
  ssr: number;          // sum of squared residuals
  ssTot: number;
  ssRes: number;
  ssReg: number;
  rSquared: number;
  rows: RegressionRow[];
}

// Result of fitting OLS on a multiple-predictor dataset
interface MultipleOLSResult {
  coefficients: number[];   // [β0, β1, ..., βk]
  residuals: number[];
  fittedValues: number[];
  rSquared: number;
  rows: RegressionRow[];
}
```

### Navigation State

```typescript
interface NavigationState {
  currentIndex: number;
  visitedIndices: Set<number>;
  glossaryOpen: boolean;
}

type NavigationAction =
  | { type: 'GO_TO'; index: number }
  | { type: 'NEXT' }
  | { type: 'BACK' }
  | { type: 'TOGGLE_GLOSSARY' };
```

### Interactive Fitting State

```typescript
interface FittingState {
  slope: number;
  intercept: number;
}

// Derived from FittingState + data — not stored, computed on render
interface FittingDerived {
  residuals: number[];
  squaredResiduals: number[];
  ssr: number;
}
```

### Custom Data Input

```typescript
interface CustomDataInput {
  raw: string;              // raw CSV text from user
  parsed: Dataset | null;
  parseError: string | null;
  missingValueRows: number[];
}
```

### OLS Computation (pure functions, no side effects)

```typescript
// Fits simple OLS: returns slope and intercept
function fitSimpleOLS(data: DataPoint[]): { slope: number; intercept: number }

// Computes residuals given data and line parameters
function computeResiduals(data: DataPoint[], slope: number, intercept: number): number[]

// Computes SSR from residuals
function computeSSR(residuals: number[]): number

// Computes R² from SS components
function computeRSquared(ssRes: number, ssTot: number): number

// Validates that a dataset has no missing values; returns affected row indices
function findMissingValueRows(dataset: Dataset): number[]
```

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Annotated Diagram Completeness

*For any* rendering of the annotated OLS formula diagram, all five required labels (Yi, β0, β1, Xi, εi) must be present with their correct descriptions, and each label must have an accompanying one-sentence plain-language description element in the DOM.

**Validates: Requirements 2.2, 2.4**

---

### Property 2: Residual Line Count Equals Data Point Count

*For any* dataset rendered in the regression line or residuals visualization, the number of vertical residual line segments drawn must equal the number of data points in the dataset.

**Validates: Requirements 3.4, 4.4**

---

### Property 3: Intercept Annotation Matches OLS Intercept

*For any* dataset and its fitted OLS line, the y-value of the intercept annotation on the regression line plot must equal the OLS-computed intercept (the value of the line at x = 0).

**Validates: Requirements 3.2**

---

### Property 4: SSR Display Equals Computed SSR for Any Line Position

*For any* dataset and any (slope, intercept) pair set by the interactive controls, the SSR value displayed on screen must equal Σ(yi − (slope·xi + intercept))² computed from those parameters and the dataset.

**Validates: Requirements 4.5, 6.2, 6.4**

---

### Property 5: Squared Residual Area Equals Squared Residual Value

*For any* dataset and any line position, for each data point i, the area of the shaded square rendered in the squared residuals plot must equal (yi − ŷi)² for that observation.

**Validates: Requirements 5.3, 6.3**

---

### Property 6: OLS Reference Line Matches OLS Solution

*For any* dataset displayed in the interactive line fitter, the reference line shown as the OLS-optimal position must have slope and intercept equal to the values produced by `fitSimpleOLS` on that dataset.

**Validates: Requirements 6.5**

---

### Property 7: Matrix Derivation Has Exactly Four Steps

*For any* rendering of the OLS matrix derivation component, exactly four numbered derivation steps must be present: (1) SSR expression, (2) derivative with respect to β, (3) set to zero, (4) solve for β̂.

**Validates: Requirements 8.4**

---

### Property 8: R² Derivation Completeness

*For any* rendering of the R² derivation component, exactly four steps must be present, each with the correct label and an accompanying plain-language interpretation sentence.

**Validates: Requirements 9.2, 9.3**

---

### Property 9: Variance Decomposition Colors Are Distinct and Consistent

*For any* rendering of the variance decomposition chart, the three segments (SS_tot, SS_res, SS_reg) must each have a distinct color, and those colors must be the same across all instances of the decomposition visualization within the module.

**Validates: Requirements 10.2**

---

### Property 10: Displayed R² Equals ssReg / ssTot

*For any* dataset and fitted model, the R² value displayed in the variance decomposition section must equal ssReg / ssTot computed from that model's residuals and the dataset's total variance.

**Validates: Requirements 10.3**

---

### Property 11: Non-Significant Variables Are Flagged

*For any* regression output row where pValue ≥ 0.05, the rendered row must include a visual indicator marking the corresponding Independent_Variable as not statistically significant at the 5% level.

**Validates: Requirements 11.6**

---

### Property 12: Each Column Header Has an Annotation

*For any* rendering of the regression output table, each of the six column headers (coef, std err, t, P>|t|, 0.025 CI, 0.975 CI) must have an associated annotation element (tooltip or inline text) containing a non-empty description.

**Validates: Requirements 12.2**

---

### Property 13: Table Row Count Equals Number of Predictors Plus One

*For any* dataset with k Independent_Variables, the regression output table must contain exactly k + 1 rows (one for the intercept and one for each predictor).

**Validates: Requirements 12.3**

---

### Property 14: Coefficient Plot Error Bars Span the 95% CI

*For any* set of regression rows, the coefficient plot must contain exactly one horizontal error bar per row, with the bar's left endpoint equal to ci95Low and right endpoint equal to ci95High for that row.

**Validates: Requirements 13.4**

---

### Property 15: Each Diagnostic Plot Renders Both Variants

*For any* diagnostic plot type (Residuals vs Fitted, Q-Q, Scale-Location), the diagnostics section must render two side-by-side instances of that plot: one in assumption-met mode and one in assumption-violated mode.

**Validates: Requirements 15.7**

---

### Property 16: Worked Example Summary Contains All Required Elements

*For any* dataset passed to the worked example, the summary output must contain all five required elements: fitted coefficients, R², T-statistics, P-values, and confidence intervals.

**Validates: Requirements 16.2**

---

### Property 17: CSV Round-Trip Produces a Regression Result

*For any* valid CSV string representing a tabular dataset with at least one numeric predictor column and one numeric outcome column, parsing the CSV and running OLS must produce a `MultipleOLSResult` with the correct number of coefficients (k + 1 where k is the number of predictor columns).

**Validates: Requirements 16.4**

---

### Property 18: Missing Value Notification Lists Affected Row Indices

*For any* dataset containing missing values, the module's missing-value notification must list every row index that contains at least one missing value, and must not list any row index that has no missing values.

**Validates: Requirements 16.5**

---

### Property 19: Progress Indicator Reflects Current Navigation Index

*For any* navigation state with current index i, the progress indicator must visually mark section i as the active section and must not mark any other section as active.

**Validates: Requirements 17.3**

---

### Property 20: Opening Glossary Does Not Change Current Section

*For any* section index i, opening the glossary drawer must leave the current section index unchanged at i.

**Validates: Requirements 17.4**

---

## Error Handling

### OLS Computation Errors

| Condition | Handling |
|-----------|----------|
| Dataset has fewer than 2 points | Display inline error: "At least 2 data points are required to fit a regression line." Disable the fit button. |
| All X values are identical (singular matrix) | Display inline error: "Cannot fit a regression line when all X values are the same (singular matrix)." |
| R² computation with zero SS_tot (all Y values identical) | Display R² as undefined with explanation: "R² is undefined when all Y values are the same." |
| CSV parse failure | Display parse error with the offending line number highlighted. |
| CSV has no numeric columns | Display: "No numeric columns found. Please upload a CSV with at least one numeric predictor and one numeric outcome column." |

### Navigation Errors

| Condition | Handling |
|-----------|----------|
| Attempt to navigate to a section index out of bounds | Clamp to [0, sections.length - 1]; no error shown to user. |
| Attempt to navigate to an unvisited section (if gating is enabled) | Show a tooltip: "Complete the current section to unlock this one." |

### Custom Data Input Errors

| Condition | Handling |
|-----------|----------|
| Missing values in uploaded dataset | Show a dismissible warning banner listing affected row indices. Offer two options: "Remove affected rows" or "Cancel upload." |
| Dataset too large (> 10,000 rows) | Show a warning: "Large datasets may affect performance. Consider using a sample." Allow the user to proceed. |

### Interactive Fitting

| Condition | Handling |
|-----------|----------|
| Slider value produces a line outside the visible plot area | Clamp the displayed line to the plot bounds; SSR continues to update correctly. |

---

## Testing Strategy

### Dual Testing Approach

Both unit tests and property-based tests are required. They are complementary:

- **Unit tests** verify specific examples, integration points, and edge cases.
- **Property tests** verify universal properties across randomly generated inputs, catching bugs that specific examples miss.

### Unit Tests

Focus areas:

- `fitSimpleOLS`: verify correct slope/intercept on a known 3-point dataset.
- `computeResiduals`: verify residual values match manual calculation.
- `computeSSR`: verify SSR = 0 when all points lie exactly on the line.
- `findMissingValueRows`: verify correct row indices returned for a dataset with known missing values.
- `RegressionOutputTable`: snapshot test verifying all 6 columns render for a known result.
- `NavigationBar`: verify that clicking a visited section index calls `onNavigate` with the correct index.
- `GlossaryDrawer`: verify that opening and closing the drawer does not change the current section index in state.
- CSV parser: verify that a well-formed CSV string produces the expected `Dataset` structure.
- CSV parser: verify that a CSV with a missing cell produces the correct `missingValueRows` array.

### Property-Based Tests

Library: **fast-check** (TypeScript). Each test runs a minimum of **100 iterations**.

Each test is tagged with a comment in the format:
`// Feature: linear-regression-explainer, Property N: <property text>`

| Property | Test Description | Generator |
|----------|-----------------|-----------|
| P1: Annotated Diagram Completeness | For any render of `AnnotatedFormulaDiagram`, all 5 labels and their descriptions are present | No generator needed — render once and assert |
| P2: Residual Line Count | For any array of DataPoints, `computeResiduals` returns an array of the same length | `fc.array(fc.record({ x: fc.float(), y: fc.float() }), { minLength: 2 })` |
| P3: Intercept Annotation | For any DataPoint array, the intercept annotation y-value equals `fitSimpleOLS(data).intercept` | Same as P2 |
| P4: SSR Display Accuracy | For any DataPoint array and (slope, intercept), displayed SSR equals computed SSR | `fc.array(DataPoint, { minLength: 2 })`, `fc.float()`, `fc.float()` |
| P5: Squared Residual Area | For any DataPoint array and line params, each square area equals (yi − ŷi)² | Same as P4 |
| P6: OLS Reference Line | For any DataPoint array, reference line params equal `fitSimpleOLS(data)` | Same as P2 |
| P7: Matrix Derivation Steps | Render `MatrixDerivation` and assert exactly 4 step elements | No generator needed |
| P8: R² Derivation Completeness | Render `RSquaredDerivation` and assert 4 steps each with a label and interpretation | No generator needed |
| P9: Decomposition Color Consistency | For any two renders of `VarianceDecompositionChart`, SS_tot/SS_res/SS_reg colors are identical | `fc.record({ ssTot: fc.float({ min: 1 }), ssRes: fc.float({ min: 0 }), ssReg: fc.float({ min: 0 }) })` |
| P10: R² Value Accuracy | For any SimpleOLSResult, displayed R² equals ssReg / ssTot | `fc.record({ ssReg: fc.float({ min: 0 }), ssTot: fc.float({ min: 0.001 }) })` |
| P11: Non-Significant Flagging | For any RegressionRow with pValue ≥ 0.05, rendered row contains significance flag | `fc.record({ pValue: fc.float({ min: 0.05, max: 1 }), ... })` |
| P12: Column Annotations Present | For any render of `RegressionOutputTable`, all 6 column headers have non-empty annotations | `fc.array(RegressionRow, { minLength: 1 })` |
| P13: Row Count | For any array of k RegressionRows (k ≥ 1), table renders k rows | `fc.array(RegressionRow, { minLength: 1, maxLength: 10 })` |
| P14: CI Error Bar Bounds | For any RegressionRow, error bar spans [ci95Low, ci95High] | `fc.record({ ci95Low: fc.float(), ci95High: fc.float() })` |
| P15: Diagnostic Plot Variants | For each of 3 plot types, both variants render | Parameterized over `DiagnosticPlotType` enum |
| P16: Worked Example Summary | For any Dataset, summary output contains all 5 required elements | `fc.record({ x: fc.array(...), y: fc.array(...) })` |
| P17: CSV Round-Trip | For any valid Dataset, serialize to CSV then parse back and run OLS → k+1 coefficients | `fc.record({ columnNames: fc.array(fc.string(), { minLength: 2 }), ... })` |
| P18: Missing Value Notification | For any Dataset with known missing rows, notification lists exactly those rows | `fc.array(DataPoint | null, { minLength: 2 })` |
| P19: Progress Indicator | For any navigation index i in [0, 15], progress indicator marks section i as active | `fc.integer({ min: 0, max: 15 })` |
| P20: Glossary Preserves Section | For any section index i, opening glossary leaves currentIndex = i | `fc.integer({ min: 0, max: 15 })` |

### Edge Cases Covered by Generators

The fast-check generators will naturally exercise:
- Empty residuals (edge-case from 7.1 — handled by `minLength: 2` constraint)
- Non-HTML / non-numeric CSV content (edge-case from 16.4 — handled by CSV parser error path)
- Special characters in column names (edge-case from 16.4)
- Datasets where all Y values are identical (R² undefined — handled by error path in Error Handling section)

