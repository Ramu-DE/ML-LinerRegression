# Requirements Document

## Introduction

An interactive educational module that teaches beginners in data science the fundamentals of Ordinary Least Squares (OLS) Linear Regression. The module covers core concepts including the OLS objective, residuals, coefficients, R-squared, t-statistics, p-values, and confidence intervals — presented progressively with annotated formula diagrams, interactive visualizations, and worked examples to build intuition before formalism. The module extends to multiple regression and includes diagnostic plots for checking OLS assumptions.

## Glossary

- **Module**: The educational tool or application that delivers the linear regression learning experience
- **Learner**: A beginner data science student using the Module to understand OLS regression
- **Explainer**: The component of the Module responsible for presenting concept definitions, worked examples, narrative explanations, and step-by-step derivations
- **Visualizer**: The component of the Module responsible for rendering charts, annotated diagrams, and interactive plots
- **OLS**: Ordinary Least Squares — a method for estimating the parameters of a linear regression model by minimizing the sum of squared residuals
- **Dependent_Variable**: The outcome variable being predicted, denoted Y (also written Yi for the i-th observation)
- **Independent_Variable**: A predictor variable used to explain Y, denoted X (or X1, X2, ..., Xk in multiple regression)
- **Residual**: The difference between an observed Y value and the value predicted by the linear model (εi = Yi − Ŷi)
- **Squared_Residual**: The square of a Residual, (Yi − Ŷi)², used in the OLS minimization objective
- **SSR**: Sum of Squared Residuals — Σ(Yi − Ŷi)², the quantity OLS minimizes
- **SS_tot**: Total Sum of Squares — Σ(Yi − Ȳ)², measuring total variance in Y
- **SS_res**: Residual Sum of Squares — Σ(Yi − Ŷi)², the unexplained variance
- **SS_reg**: Regression Sum of Squares — SS_tot − SS_res, the variance explained by the model
- **Coefficient**: A parameter (β0, β1, ..., βk) representing the change in Y for a one-unit change in the corresponding Independent_Variable, holding all other variables constant
- **Intercept**: β0 — the predicted value of Y when all Independent_Variables equal zero
- **Slope**: β1 (in simple regression) — the change in Y per one-unit increase in X, visualized as rise/run on the regression line
- **R_Squared**: A statistic measuring the proportion of variance in the Dependent_Variable that is predictable from the Independent_Variables, ranging from 0 to 1
- **T_Statistic**: A value used to test the null hypothesis that a Coefficient equals zero, computed as Coefficient / Standard_Error
- **P_Value**: The probability of observing a T_Statistic as extreme as the one computed, assuming the null hypothesis is true
- **Confidence_Interval**: A range of plausible values for a Coefficient at a specified confidence level (default 95%)
- **Standard_Error**: The estimated standard deviation of a Coefficient estimate
- **Best_Fit_Line**: The linear equation whose Coefficients minimize the sum of squared Residuals
- **Design_Matrix**: The matrix X whose rows are observations and columns are Independent_Variables (plus a column of ones for the Intercept)
- **OLS_Solution**: The closed-form matrix expression β̂ = (XᵀX)⁻¹Xᵀy that yields the Best_Fit_Line Coefficients
- **Diagnostic_Plot**: A chart used to visually assess whether a specific OLS assumption holds for a fitted model

---

## Requirements

### Requirement 1: OLS Concept Introduction

**User Story:** As a Learner, I want a clear explanation of what OLS regression is and what problem it solves, so that I understand the purpose of the technique before seeing any math.

#### Acceptance Criteria

1. THE Explainer SHALL present a plain-language definition of OLS regression before displaying any formulas or equations.
2. THE Explainer SHALL describe the relationship between a Dependent_Variable and one or more Independent_Variables using concrete, real-world examples.
3. WHEN a Learner views the OLS introduction section, THE Explainer SHALL display the general form of the linear equation (Y = β0 + β1·X1 + ... + βk·Xk + ε) alongside a plain-language interpretation of each term.

---

### Requirement 2: Annotated OLS Formula Diagram

**User Story:** As a Learner, I want to see the OLS equation with each term visually labeled, so that I can connect the mathematical notation to its real-world meaning before working through the math.

#### Acceptance Criteria

1. WHEN a Learner views the formula introduction section, THE Visualizer SHALL render an annotated diagram of the simple OLS equation (Yi = β0 + β1·Xi + εi) with labeled arrows pointing to each term.
2. THE Visualizer SHALL label Yi as "Dependent Variable", β0 as "Population Y Intercept", β1 as "Population Slope Coefficient", Xi as "Independent Variable", and εi as "Random Error term".
3. THE Visualizer SHALL visually distinguish the "Linear component" (β0 + β1·Xi) from the "Random Error component" (εi) within the annotated diagram, using distinct colors or grouping brackets.
4. THE Explainer SHALL accompany the annotated diagram with a one-sentence plain-language description of each labeled term.

---

### Requirement 3: Regression Line Visualization

**User Story:** As a Learner, I want to see the regression line plotted on a scatter plot with the intercept and slope visually marked, so that I can understand what β0 and β1 mean geometrically.

#### Acceptance Criteria

1. WHEN a Learner views the regression line section, THE Visualizer SHALL render a scatter plot of observed data points with the Best_Fit_Line overlaid.
2. THE Visualizer SHALL mark the Intercept (b0) as the point where the Best_Fit_Line crosses the Y-axis, with a labeled annotation on the Y-axis.
3. THE Visualizer SHALL illustrate the Slope (b1) as a rise/run triangle drawn on the Best_Fit_Line, with the rise and run segments labeled.
4. THE Visualizer SHALL draw vertical colored lines from each observed data point to the Best_Fit_Line, representing each Residual.
5. THE Explainer SHALL label the vertical lines as "Residuals (error terms)" and explain that OLS minimizes the total of their squared lengths.

---

### Requirement 4: Residuals and the Sum of Squares

**User Story:** As a Learner, I want to understand what residuals are and why minimizing their squared sum defines the "best fit," so that I can grasp the core optimization objective of OLS.

#### Acceptance Criteria

1. THE Explainer SHALL define a Residual as the difference between an observed Dependent_Variable value and the value predicted by the linear model.
2. THE Explainer SHALL explain why squaring Residuals (rather than summing raw differences) is used to define the OLS objective.
3. THE Explainer SHALL state that OLS finds the Best_Fit_Line by minimizing the SSR, and SHALL display the corresponding mathematical expression: min Σ(Yi − Ŷi)².
4. WHEN a Learner views the residuals section, THE Visualizer SHALL render a scatter plot showing observed data points, the Best_Fit_Line, and vertical lines representing each Residual.
5. WHEN a Learner interacts with the residuals visualization, THE Visualizer SHALL update the displayed SSR value in real time as the Learner adjusts the position of the Best_Fit_Line.

---

### Requirement 5: Squared Residuals Visualization

**User Story:** As a Learner, I want to see residuals represented as squares whose area equals the squared residual, so that I can visually understand what OLS is minimizing.

#### Acceptance Criteria

1. WHEN a Learner views the squared residuals section, THE Visualizer SHALL render a side-by-side comparison of two plots using the same dataset and Best_Fit_Line.
2. THE Visualizer SHALL render the left plot as a residuals plot showing observed data points, the Best_Fit_Line in red, and dotted vertical lines from each data point to the line representing each Residual.
3. THE Visualizer SHALL render the right plot as a squared residuals plot showing the same elements, with each Residual additionally represented as a shaded square whose area equals the Squared_Residual value for that observation.
4. THE Explainer SHALL annotate the squared residuals plot with the label "OLS minimizes the total area of all squares" to make the minimization objective visually intuitive.
5. WHEN the Best_Fit_Line position changes in either plot, THE Visualizer SHALL update both plots and the total SSR display simultaneously.

---

### Requirement 6: Interactive Line Fitting

**User Story:** As a Learner, I want to drag the regression line and see residuals and SSR update in real time, so that I can build intuition for why OLS finds a unique minimum.

#### Acceptance Criteria

1. THE Visualizer SHALL allow the Learner to drag the Best_Fit_Line by adjusting its Slope and Intercept using on-screen controls (such as sliders or direct drag handles).
2. WHEN the Learner adjusts the Best_Fit_Line, THE Visualizer SHALL update the Residual lines in real time.
3. WHEN the Learner adjusts the Best_Fit_Line, THE Visualizer SHALL update the shaded Squared_Residual areas in real time.
4. WHEN the Learner adjusts the Best_Fit_Line, THE Visualizer SHALL update the total SSR value in real time.
5. THE Visualizer SHALL display the OLS-optimal position of the Best_Fit_Line as a reference, so the Learner can compare their manually adjusted line to the true minimum.
6. THE Explainer SHALL include a note explaining that the OLS solution is the unique line position that produces the globally minimum SSR.

---

### Requirement 7: Coefficients Interpretation

**User Story:** As a Learner, I want to understand what each coefficient means in practical terms, so that I can interpret a fitted regression model correctly.

#### Acceptance Criteria

1. THE Explainer SHALL define each Coefficient (β0, β1, ..., βk) and describe its role in the linear equation.
2. THE Explainer SHALL explain that β0 is the Intercept — the predicted value of Y when all Independent_Variables equal zero.
3. THE Explainer SHALL explain that each βi represents the expected change in Y for a one-unit increase in Xi, holding all other Independent_Variables constant.
4. WHEN a Learner views the coefficients section, THE Explainer SHALL provide a worked numeric example demonstrating how to interpret a specific Coefficient value in a real-world context.
5. IF a Learner provides a dataset with more than one Independent_Variable, THEN THE Explainer SHALL illustrate the "holding other variables constant" interpretation using that dataset.

---

### Requirement 8: Mathematical Derivation of OLS Coefficients

**User Story:** As a Learner, I want to see how the OLS coefficient formula is derived, so that I understand where the numbers come from rather than treating them as a black box.

#### Acceptance Criteria

1. THE Explainer SHALL present the closed-form OLS solution β̂ = (XᵀX)⁻¹Xᵀy and identify it as the formula that produces the Best_Fit_Line Coefficients.
2. THE Explainer SHALL describe the Design_Matrix X in plain language — explaining that each row is one observation and each column is one Independent_Variable, with an added column of ones to capture the Intercept.
3. THE Explainer SHALL explain in plain language why the term (XᵀX)⁻¹ is needed, without assuming the Learner has prior linear algebra knowledge.
4. THE Explainer SHALL show the derivation as a step-by-step sequence: (1) write the SSR expression, (2) take the derivative with respect to β, (3) set it to zero, (4) solve for β̂ — with each step accompanied by a plain-language description of what is happening mathematically.
5. THE Explainer SHALL connect the matrix derivation back to the simple two-variable case (β̂1 = Σ(Xi−X̄)(Yi−Ȳ) / Σ(Xi−X̄)²) so the Learner can verify the formula on a small numeric example.

---

### Requirement 9: R-Squared Step-by-Step Derivation

**User Story:** As a Learner, I want to see R-squared derived step by step with plain-language explanations at each step, so that I understand what it actually measures rather than just memorizing the formula.

#### Acceptance Criteria

1. THE Explainer SHALL define R_Squared as the proportion of variance in the Dependent_Variable that is explained by the Independent_Variables.
2. THE Explainer SHALL present R_Squared as a four-step derivation in the following sequence:
   - Step 1: R² = 1 − (SS_res / SS_tot), labeled "Residual variance subtracted from 1"
   - Step 2: = (SS_tot − SS_res) / SS_tot, labeled "Rearranged as a fraction"
   - Step 3: = SS_reg / SS_tot, labeled "Explained variance over total variance"
   - Step 4: = Fraction of total variance explained, labeled "Plain-language interpretation"
3. THE Explainer SHALL accompany each derivation step with a one-sentence plain-language interpretation of what that step means.
4. THE Explainer SHALL state that R_Squared ranges from 0 to 1, where 0 indicates no explanatory power and 1 indicates that the model explains all variance in the Dependent_Variable.
5. THE Explainer SHALL warn the Learner that a high R_Squared value does not by itself confirm that the model is correct or that the relationships are causal.

---

### Requirement 10: Variance Decomposition Visualization

**User Story:** As a Learner, I want to see SS_tot, SS_res, and SS_reg shown as distinct visual areas, so that I can see how R-squared partitions total variance.

#### Acceptance Criteria

1. WHEN a Learner views the R-squared section, THE Visualizer SHALL render a variance decomposition visualization showing SS_tot, SS_res, and SS_reg as distinct, labeled visual areas or bar segments.
2. THE Visualizer SHALL use consistent colors to distinguish SS_tot (total), SS_res (unexplained), and SS_reg (explained) across the decomposition visualization and any related plots.
3. THE Visualizer SHALL display the computed R_Squared value alongside the decomposition, updating it when the dataset or model changes.
4. THE Explainer SHALL annotate the decomposition visualization with the equation SS_tot = SS_reg + SS_res so the Learner can see the additive relationship directly.
5. WHEN a Learner views the R-squared section, THE Visualizer SHALL display a visual comparison between a low-R² fit and a high-R² fit on the same dataset, using the variance decomposition to show why one fit explains more variance.

---

### Requirement 11: T-Statistics and P-Values

**User Story:** As a Learner, I want to understand t-statistics and p-values for each coefficient, so that I can determine which Independent_Variables have a statistically significant relationship with the Dependent_Variable.

#### Acceptance Criteria

1. THE Explainer SHALL define the T_Statistic for a Coefficient as the ratio of the estimated Coefficient to its Standard_Error.
2. THE Explainer SHALL define the P_Value as the probability of observing a T_Statistic at least as extreme as the computed value, assuming the null hypothesis (Coefficient = 0) is true.
3. THE Explainer SHALL state that a P_Value below 0.05 is conventionally used to reject the null hypothesis that the Coefficient equals zero.
4. WHEN a Learner views the significance section, THE Explainer SHALL display a worked example showing how to read a regression output table containing Coefficients, T_Statistics, and P_Values.
5. THE Explainer SHALL explain that failing to reject the null hypothesis does not prove the Coefficient is zero, only that the data do not provide sufficient evidence against it.
6. IF a P_Value is greater than or equal to 0.05, THEN THE Explainer SHALL indicate that the corresponding Independent_Variable is not statistically significant at the 5% level.

---

### Requirement 12: Regression Output Table

**User Story:** As a Learner, I want to see a full regression output table with each column explained, so that I can read real-world regression output (e.g., from statsmodels) without confusion.

#### Acceptance Criteria

1. WHEN a Learner views the regression output section, THE Module SHALL display a regression output table with the following columns: coef, std err, t, P>|t|, [0.025 CI, 0.975 CI].
2. THE Explainer SHALL annotate each column of the regression output table with a tooltip or inline explanation: "coef" as the estimated Coefficient value, "std err" as the Standard_Error of the estimate, "t" as the T_Statistic, "P>|t|" as the P_Value, and "[0.025, 0.975]" as the lower and upper bounds of the 95% Confidence_Interval.
3. THE Module SHALL include rows for the Intercept (const) and each Independent_Variable in the regression output table.
4. THE Explainer SHALL provide a worked narrative that walks the Learner through reading one complete row of the regression output table, interpreting each column value in plain language.
5. WHEN a Learner hovers over or selects a column header in the regression output table, THE Module SHALL display the annotation for that column.

---

### Requirement 13: Confidence Intervals

**User Story:** As a Learner, I want to understand confidence intervals for coefficients, so that I can communicate the uncertainty around my estimates.

#### Acceptance Criteria

1. THE Explainer SHALL define a Confidence_Interval as a range of plausible values for a Coefficient at a specified confidence level.
2. THE Explainer SHALL state that the default confidence level used in the Module is 95%, and SHALL explain what "95% confidence" means in frequentist terms.
3. THE Explainer SHALL display the formula for a 95% Confidence_Interval: [β̂ − 1.96·SE, β̂ + 1.96·SE], where SE is the Standard_Error of the Coefficient.
4. WHEN a Learner views the confidence intervals section, THE Visualizer SHALL render a coefficient plot showing point estimates and their 95% Confidence_Intervals as horizontal error bars.
5. THE Explainer SHALL explain the relationship between the Confidence_Interval and the P_Value — specifically that a 95% Confidence_Interval that excludes zero corresponds to a P_Value below 0.05.

---

### Requirement 14: Multiple Regression Formula

**User Story:** As a Learner, I want to see how simple regression extends to multiple predictors, so that I understand the general form of the model and how each additional variable contributes.

#### Acceptance Criteria

1. THE Explainer SHALL present the multiple regression formula y = β0 + β1X1 + β2X2 + ... + βkXk + ε alongside the simple regression formula y = β0 + β1X1 + ε.
2. THE Explainer SHALL explain that each additional Independent_Variable adds one dimension to the model, and that the Best_Fit_Line becomes a hyperplane in higher-dimensional space.
3. THE Explainer SHALL describe how each Coefficient βi in the multiple regression formula represents the effect of Xi on Y while holding all other Independent_Variables constant.
4. THE Explainer SHALL provide a concrete example with two Independent_Variables (k=2) and explain the interpretation of each Coefficient in plain language.
5. THE Visualizer SHALL render a 3D scatter plot for the two-predictor case (k=2) showing the fitted regression plane, so the Learner can see how the model extends beyond a line.

---

### Requirement 15: OLS Assumption Diagnostic Plots

**User Story:** As a Learner, I want to see diagnostic plots that check OLS assumptions, so that I can identify when my model may be violating those assumptions.

#### Acceptance Criteria

1. WHEN a Learner views the diagnostics section, THE Visualizer SHALL render a Residuals vs Fitted plot showing Residuals on the Y-axis and fitted values (Ŷi) on the X-axis.
2. THE Explainer SHALL annotate the Residuals vs Fitted plot with an explanation that a random scatter around zero indicates the linearity and homoscedasticity assumptions are met, while a curved or funnel-shaped pattern indicates a violation.
3. WHEN a Learner views the diagnostics section, THE Visualizer SHALL render a Q-Q plot of the standardized Residuals against theoretical normal quantiles.
4. THE Explainer SHALL annotate the Q-Q plot with an explanation that points falling close to the diagonal line indicate the normality assumption is met, while systematic deviations indicate non-normality.
5. WHEN a Learner views the diagnostics section, THE Visualizer SHALL render a Scale-Location plot showing the square root of standardized Residuals against fitted values.
6. THE Explainer SHALL annotate the Scale-Location plot with an explanation that a roughly horizontal band indicates homoscedasticity, while a widening or narrowing band indicates heteroscedasticity.
7. THE Explainer SHALL present each Diagnostic_Plot with a side-by-side example showing what the plot looks like when the assumption holds versus when it is violated.

---

### Requirement 16: Interactive Worked Example

**User Story:** As a Learner, I want to work through a complete OLS regression example from raw data to interpretation, so that I can see how all the concepts connect end to end.

#### Acceptance Criteria

1. THE Module SHALL provide a built-in sample dataset that a Learner can use to run a complete OLS regression without supplying external data.
2. WHEN a Learner runs the worked example, THE Module SHALL display the fitted Coefficients, R_Squared, T_Statistics, P_Values, and Confidence_Intervals in a single summary output.
3. THE Explainer SHALL provide a step-by-step narrative that walks the Learner through interpreting each element of the summary output.
4. WHERE the Module supports custom data input, THE Module SHALL accept a tabular dataset from the Learner and rerun the worked example using that dataset.
5. IF a Learner-supplied dataset contains missing values, THEN THE Module SHALL notify the Learner of the rows affected and SHALL describe how missing values are handled before fitting the model.

---

### Requirement 17: Progressive Disclosure and Navigation

**User Story:** As a Learner, I want to move through concepts in a logical order and revisit earlier sections, so that I can learn at my own pace without feeling overwhelmed.

#### Acceptance Criteria

1. THE Module SHALL present concepts in the following order: OLS introduction → Annotated Formula Diagram → Regression Line Visualization → Residuals and Sum of Squares → Squared Residuals Visualization → Interactive Line Fitting → Coefficients → OLS Coefficient Derivation → R-Squared Derivation → Variance Decomposition → T-Statistics and P-Values → Regression Output Table → Confidence Intervals → Multiple Regression → Diagnostic Plots → Worked Example.
2. WHEN a Learner completes a section, THE Module SHALL provide a navigation control to proceed to the next section or return to any previously visited section.
3. THE Module SHALL display a progress indicator showing the Learner's current position within the full sequence of sections.
4. WHILE a Learner is on any section, THE Module SHALL allow the Learner to access the Glossary without leaving the current section.
